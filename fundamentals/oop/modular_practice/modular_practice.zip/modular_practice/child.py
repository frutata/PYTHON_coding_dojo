import parent

print("---------------------------------------------")

print(locals())